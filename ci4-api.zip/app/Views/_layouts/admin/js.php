<script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin@7.0.7/dist/js/scripts.min.js"></script>
<script src="<?= base_url("assets/js/main.js") . "?t=" . time() ?>"></script>